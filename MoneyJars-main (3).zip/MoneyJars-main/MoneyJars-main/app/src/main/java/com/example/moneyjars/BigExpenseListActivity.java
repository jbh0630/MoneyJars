package com.example.moneyjars;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BigExpenseListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_big_expense_list);
    }
}