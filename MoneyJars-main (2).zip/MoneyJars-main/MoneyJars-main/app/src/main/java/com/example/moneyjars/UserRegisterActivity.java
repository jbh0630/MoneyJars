package com.example.moneyjars;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class UserRegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);



        EditText email = findViewById(R.id.inputID2);
        EditText password = findViewById(R.id.inputPwd2);
        EditText confirmPassword = findViewById(R.id.inputPwd3);
        Button singup = findViewById(R.id.button);
        FirebaseAuth fAuth = FirebaseAuth.getInstance();

//        if(fAuth.getCurrentUser() != null){
//            Intent Home = new Intent(UserRegisterActivity.this,UserRegister2Activity.class);
//            startActivity(Home);
//            //startActivity(new Intent(getApplicationContext(),HomeActivity.class));
//            finish();
//        }

        singup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Cemail = email.getText().toString();
                String Cpassword = password.getText().toString();
                String CconfirmPassword = confirmPassword.getText().toString();

                if(TextUtils.isEmpty(Cemail)){
                    email.setError("Email is required.");
                }
                if(TextUtils.isEmpty(Cpassword)){
                    password.setError("Password is required.");
                }
                if(TextUtils.isEmpty(CconfirmPassword)){
                    confirmPassword.setError("Confirm password is required.");
                    password.setError("");
                }
                if(Cpassword.length() < 6){
                    password.setError("Password must be larger than 6 characters");
                }
                if(!CconfirmPassword.equals(Cpassword)){
                    confirmPassword.setError("Confirm password need to be same with password");
                    password.setError("Confirm password need to be same with password");
                }

                //register user in firebase
                fAuth.createUserWithEmailAndPassword(Cemail, Cpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(UserRegisterActivity.this,"User Created", Toast.LENGTH_SHORT).show();
                            Intent Home = new Intent(UserRegisterActivity.this,UserRegister2Activity.class);
                            startActivity(Home);

                            //startActivity(new Intent(getApplicationContext(),HomeActivity.class));

                        }else {
                            Toast.makeText(UserRegisterActivity.this,"Error !", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });


    }
}