package com.example.moneyjars;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class WelcomeActivity extends AppCompatActivity {
    DatabaseHelper_userData userData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText email = findViewById(R.id.inputID);
        EditText password = findViewById(R.id.inputPwd);
        Button login = findViewById(R.id.btnLogin);
        FirebaseAuth fAuth = FirebaseAuth.getInstance();
        CheckedTextView signUp = findViewById(R.id.btnSignUp);
        CheckedTextView forgotPass = findViewById(R.id.btnForgotPass);
        userData = new DatabaseHelper_userData(this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String CEmail = email.getText().toString();
                String CPassword = password.getText().toString();

                if(CEmail.equals("")){
                    Toast.makeText(WelcomeActivity.this,"Please enter email", Toast.LENGTH_SHORT).show();
                }
                else if(CPassword.equals("")){
                    Toast.makeText(WelcomeActivity.this,"Please enter password", Toast.LENGTH_SHORT).show();
                }
                else{
                    boolean checkUser = userData.verifiedUser(CEmail, CPassword);
                    if(checkUser == true){
                        Toast.makeText(WelcomeActivity.this,"Successfully", Toast.LENGTH_SHORT).show();
                        Intent homeActivity = new Intent(WelcomeActivity.this,HomeActivity.class);
                        homeActivity.putExtra("user_email", CEmail);
                        startActivity(homeActivity);
                    }else {
                        Toast.makeText(WelcomeActivity.this,"Error !", Toast.LENGTH_SHORT).show();
                    }
                }

//
//
//                if(TextUtils.isEmpty(CEmail)){
//                    email.setError("Email is required.");
//                }
//                if(TextUtils.isEmpty(CPassword)){
//                    password.setError("Password is required.");
//                }
//
//                if(password.length() < 6){
//                    password.setError("Password must be larger than 6 characters");
//                }
//
//                fAuth.signInWithEmailAndPassword(CEmail,CPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if(task.isSuccessful()){
//                            Toast.makeText(WelcomeActivity.this,"Successfully", Toast.LENGTH_SHORT).show();
//                            startActivity(new Intent(getApplicationContext(),HomeActivity.class));
//                        }else {
//                            Toast.makeText(WelcomeActivity.this,"Error !", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                });

            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),UserRegisterActivity.class));
            }
        });

        forgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                EditText resetMail = new EditText(v.getContext());
//                AlertDialog.Builder passwordResetDialog = new AlertDialog.Builder(v.getContext());
//                passwordResetDialog.setTitle("Reset Password?");
//                passwordResetDialog.setMessage("Enter your Email to received reset link");
//                passwordResetDialog.setView(resetMail);
//
//                passwordResetDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        String mail = resetMail.getText().toString();
//                        fAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
//                            @Override
//                            public void onSuccess(Void aVoid) {
//                                Toast.makeText(WelcomeActivity.this,"Reset Link Send to your Email",Toast.LENGTH_LONG).show();
//
//                            }
//                        }).addOnFailureListener(new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception e) {
//                                Toast.makeText(WelcomeActivity.this, "Error! Reset link is not send" + e.getMessage(),Toast.LENGTH_SHORT).show();
//                            }
//                        });
//                    }
//                });
//                passwordResetDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                    }
//                });
//                passwordResetDialog.create().show();

            }
        });
    }
}