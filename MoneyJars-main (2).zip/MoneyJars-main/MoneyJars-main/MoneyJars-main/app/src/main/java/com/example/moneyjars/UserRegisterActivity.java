package com.example.moneyjars;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class UserRegisterActivity extends AppCompatActivity {
    DatabaseHelper_userData userData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);

        EditText fName = findViewById(R.id.txtUserFName);
        EditText lName = findViewById(R.id.txtUserLName);
        EditText email = findViewById(R.id.txtEmail);
        EditText password = findViewById(R.id.txtPassword);
        EditText confirmPassword = findViewById(R.id.txtRepassword);
        Button singUp = findViewById(R.id.button);
        userData = new DatabaseHelper_userData(this);
//        FirebaseAuth fAuth = FirebaseAuth.getInstance();

//        if(fAuth.getCurrentUser() != null){
//            Intent Home = new Intent(UserRegisterActivity.this,UserRegister2Activity.class);
//            startActivity(Home);
//            //startActivity(new Intent(getApplicationContext(),HomeActivity.class));
//            finish();
//        }

        singUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String UFName = fName.getText().toString();
                String ULName = lName.getText().toString();
                String Cemail = email.getText().toString();
                String Cpassword = password.getText().toString();
                String CconfirmPassword = confirmPassword.getText().toString();

                if(TextUtils.isEmpty(UFName)){
                    fName.setError("First name is required.");
                }
                else if(TextUtils.isEmpty(ULName)){
                    lName.setError("Last name is required.");
                }
                else if(TextUtils.isEmpty(Cemail)){
                    email.setError("Email is required.");
                }
                else if(TextUtils.isEmpty(Cpassword)){
                    password.setError("Password is required.");
                }
                else if(TextUtils.isEmpty(CconfirmPassword)){
                    confirmPassword.setError("Confirm password is required.");
                    password.setError("");
                }
                else if(Cpassword.length() < 6){
                    password.setError("Password must be larger than 6 characters");
                }
                else if(!CconfirmPassword.equals(Cpassword)){
                    confirmPassword.setError("Confirm password need to be same with password");
                    password.setError("Confirm password need to be same with password");
                }
                else if(Cpassword.equals(CconfirmPassword)){
                    boolean create = userData.addUser(Cemail, UFName, ULName, Cpassword);
                    if(create == true){
                        Toast.makeText(UserRegisterActivity.this,"User Created",Toast.LENGTH_SHORT).show();
                        Intent addInformation = new Intent(UserRegisterActivity.this,UserRegister2Activity.class);
                        startActivity(addInformation);
                    }
                    else{
                        Toast.makeText(UserRegisterActivity.this,"Error !", Toast.LENGTH_SHORT).show();
                    }
                }



//                //register user in firebase
//                fAuth.createUserWithEmailAndPassword(Cemail, Cpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if(task.isSuccessful()){
//                            Toast.makeText(UserRegisterActivity.this,"User Created", Toast.LENGTH_SHORT).show();
//                            Intent Home = new Intent(UserRegisterActivity.this,UserRegister2Activity.class);
//                            startActivity(Home);
//
//                            //startActivity(new Intent(getApplicationContext(),HomeActivity.class));
//
//                        }else {
//                            Toast.makeText(UserRegisterActivity.this,"Error !", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                });
            }
        });


    }
}