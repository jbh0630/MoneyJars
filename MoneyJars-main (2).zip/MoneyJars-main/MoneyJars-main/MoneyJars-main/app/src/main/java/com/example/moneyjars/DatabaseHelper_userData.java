package com.example.moneyjars;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper_userData extends SQLiteOpenHelper {

    final static String DATABASE_NAME = "UserInformation.db";
    final static int DATABASE_VERSION = 1;
    final static String TABLE_NAME = "User";
    final static String T1COL_1 = "Email";
    final static String T1COL_2 = "FName";
    final static String T1COL_3 = "LName";
    final static String T1COL_4 = "Password";
    final static String T1COL_5 = "Role";

    public DatabaseHelper_userData(@Nullable Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + "(" +
                T1COL_1 + " TEXT PRIMARY KEY," +
                T1COL_2 + " TEXT," +
                T1COL_3 + " TEXT," +
                T1COL_4 + " TEXT," +
                T1COL_5 + " TEXT)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addUser(String email,String fn, String ln,String password){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(T1COL_1, email);
        values.put(T1COL_2, fn);
        values.put(T1COL_3, ln);
        values.put(T1COL_4, password);
        values.put(T1COL_5, "user");

        long r = sqLiteDatabase.insert(TABLE_NAME, null, values);
        if(r>0)
            return true;
        else
            return false;
    }

    public boolean deleteUser(String email){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        int d = sqLiteDatabase.delete(TABLE_NAME,"email=?", new String[]{email});
        if(d>0)
            return  true;
        else
            return false;

        //another way
        //String query = "DELETE FROM " + TABLE1_NAME + " where Id= " + id;
        //sqLiteDatabase.execSQL(query);
        //return true;
    }

    public boolean verifiedUser(String email, String password){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor c = sqLiteDatabase.rawQuery(query + " WHERE email=? and password=?", new String[] {email, password});

        if(c.getCount()>0)
            return true;
        else
            return false;
    }

    public String getUserFName(String email){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor c = sqLiteDatabase.rawQuery(query + " WHERE email=?", new String[] {email});
        String FName = c.getString(c.getColumnIndex("FName"));

        return FName;
    }

    public boolean updateFN(String email, String fn){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(T1COL_2, fn);
        int d = sqLiteDatabase.update(TABLE_NAME,values,"email=?",
                new String[]{email});
        if(d>0)
            return true;
        else
            return false;
    }
    public boolean updateLN(String email, String ln){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(T1COL_3, ln);
        int d = sqLiteDatabase.update(TABLE_NAME,values,"email=?",
                new String[]{email});
        if(d>0)
            return true;
        else
            return false;
    }
    public boolean updatePassword(String email, String pw){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(T1COL_4, pw);
        int d = sqLiteDatabase.update(TABLE_NAME,values,"email=?",
                new String[]{email});
        if(d>0)
            return true;
        else
            return false;
    }
    public boolean updateRole(String email, String role){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(T1COL_5, role);
        int d = sqLiteDatabase.update(TABLE_NAME,values,"email=?",
                new String[]{email});
        if(d>0)
            return true;
        else
            return false;
    }
}
