package com.example.moneyjars;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
    DatabaseHelper_userData userData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        String email = getIntent().getStringExtra("user_email");
        TextView userName = findViewById(R.id.txtWelcomeUserFName);
        userData = new DatabaseHelper_userData(this);

        //userName.setText(userData.getUserFName(email));
    }

}